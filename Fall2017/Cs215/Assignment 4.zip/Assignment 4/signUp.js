var SignUpValidation= document.getElementById("button");

SignUpValidation.addEventListener("click", functionSet1,false);







