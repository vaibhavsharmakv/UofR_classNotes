
var loginValidation = document.getElementById("b2");

loginValidation.addEventListener("click",functionSet2,false);

var secretMessageValidation =document.getElementById("btn");

secretMessageValidation.addEventListener("click",passcode,false);
